<?php

namespace App\Http\Controllers\Api\v1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;

class DashboardController extends Controller
{
    public function getShipperDashboard(Request $request)
    {
        if ($request->user) {
            $user = $request->user;
            return response()->json(['user' => $user, 'status' => 200], 200);
        }
        return response()->json(['error' => 'You are not authorized to access this page', 'status' => 401], 401);
    }

    public function getCarrierDashboard(Request $request)
    {
        if ($request->user) {
            $user = $request->user;
            return response()->json(['user' => $user, 'status' => 200], 200);
        }
        return response()->json(['error' => 'You are not authorized to access this page', 'status' => 401], 401);
    }
}
